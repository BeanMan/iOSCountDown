//
//  CountDownView.m
//  timeEnd
//
//  Created by bean on 16/2/18.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import "CountDownView.h"

#define TIMELABELWIDTH 40
#define HEIGHT 40
#define COLONLABELWIDTH 10
#define Y 0
@implementation CountDownView
{
    NSTimer *timer ; //定时器
}


- (instancetype)initWithFrame:(CGRect)frame
{
    CGRect myFrame = CGRectMake(0, frame.origin.y, [[UIScreen mainScreen] bounds].size.width, 50) ;
    if ([super initWithFrame:myFrame])
    {
        [self addSubview:self.colonAfterDayLabel] ;
        [self addSubview:self.colonAfterHourLabel] ;
        [self addSubview:self.colonAfterMinuteLabel] ;
    }
    return self ;
}
// 每个时间Label宽度 50 高度40  每个冒号Label宽度10 高度40 相连放置即可
// 懒加载
- (UILabel *)dayLabel
{
    if (!_dayLabel)
    {
        _dayLabel = [[UILabel alloc] initWithFrame:CGRectMake(50, Y, TIMELABELWIDTH, HEIGHT)] ;
        _dayLabel.textAlignment = NSTextAlignmentCenter ;
        [self addSubview:_dayLabel] ;
    }
    return _dayLabel ;
}

- (UILabel *)colonAfterDayLabel
{
    if (!_colonAfterDayLabel)
    {
        _colonAfterDayLabel = [[UILabel alloc] initWithFrame:CGRectMake(50+TIMELABELWIDTH, Y, COLONLABELWIDTH, HEIGHT)] ;
        _colonAfterDayLabel.text = @":" ;
        _colonAfterDayLabel.textAlignment = NSTextAlignmentCenter ;
    }
    return _colonAfterDayLabel ;
}

- (UILabel *)hourLabel
{
    if (!_hourLabel)
    {
        _hourLabel = [[UILabel alloc] initWithFrame:CGRectMake(50 + TIMELABELWIDTH + COLONLABELWIDTH, Y, TIMELABELWIDTH, HEIGHT)] ;
        _hourLabel.textAlignment = NSTextAlignmentCenter ;
        [self addSubview:_hourLabel] ;
    }
    return _hourLabel ;
}

- (UILabel *)colonAfterHourLabel
{
    if (!_colonAfterHourLabel)
    {
        _colonAfterHourLabel = [[UILabel alloc] initWithFrame:CGRectMake(50 + TIMELABELWIDTH*2 + 10, Y, COLONLABELWIDTH, HEIGHT)] ;
        _colonAfterHourLabel.text = @":" ;
        _colonAfterHourLabel.textAlignment = NSTextAlignmentCenter ;
    }
    return _colonAfterHourLabel ;
}

- (UILabel *)minuteLabel
{
    if (!_minuteLabel)
    {
        _minuteLabel = [[UILabel alloc] initWithFrame:CGRectMake(50+(TIMELABELWIDTH + COLONLABELWIDTH)*2, Y, TIMELABELWIDTH, HEIGHT)] ;
        _minuteLabel.textAlignment = NSTextAlignmentCenter ;
        [self addSubview:_minuteLabel] ;
    }
    return _minuteLabel ;
}

- (UILabel *)colonAfterMinuteLabel
{
    if (!_colonAfterMinuteLabel)
    {
        _colonAfterMinuteLabel = [[UILabel alloc] initWithFrame:CGRectMake(50 + TIMELABELWIDTH*3 + COLONLABELWIDTH *2, Y, COLONLABELWIDTH, HEIGHT)] ;
        _colonAfterMinuteLabel.text = @":" ;
        _colonAfterMinuteLabel.textAlignment = NSTextAlignmentCenter ;
        
    }
    return _colonAfterMinuteLabel ;
}

- (UILabel *)secondLabel
{
    if (!_secondLabel)
    {
        _secondLabel = [[UILabel alloc] initWithFrame:CGRectMake(50 + (TIMELABELWIDTH + COLONLABELWIDTH)*3, Y, TIMELABELWIDTH, HEIGHT)] ;
        _secondLabel.textAlignment = NSTextAlignmentCenter ;
        [self addSubview:_secondLabel] ;
    }
    return _secondLabel ;
}

// 当我们给时间间隔赋值时,生成定时器
- (void)setTimeInterval:(NSInteger)timeInterval
{
    _timeInterval = timeInterval ;
    if (_timeInterval!=0)
    {
        timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerAction) userInfo:nil repeats:YES] ;
    }
}

// 获取时间间隔
- (NSTimeInterval)timeIntervalWithFormatterString : (NSString *)formatterString andFutureDataString : (NSString *)futureDataString
{
    // 获取当前时间
    NSDate *date = [NSDate date] ;
    // 创建时间格式对象
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init] ;
    // 设置时间格式
    [dateFormatter setDateFormat:formatterString] ;
    // 将你需要的时间格式字符串转化为日期对象
    NSDate *futureDate = [dateFormatter dateFromString:futureDataString] ;
    // 获取当前时间距你所需要时间的时间间隔
    NSTimeInterval timerInterval = [futureDate timeIntervalSinceDate:date] ;
    return timerInterval ;
}

// 每间隔一秒定时器触发执行该方法
- (void)timerAction
{
    // 定时器每次触发 时间间隔减一 也就是说时间间隔依次递减
    _timeInterval -- ;
    [self getTimeFromTimeInterval:_timeInterval] ;
    // 当时间间隔为0时干掉定时器
    if (_timeInterval == 0)
    {
        [timer invalidate] ;
        timer = nil ;
        //如果时间到了，定时器就停了
        
#pragma mark  计时器到了做处理
        /*******计时器到了做处理*******/
        [self.dayLabel removeFromSuperview];
        [self.hourLabel removeFromSuperview];
        [self.minuteLabel removeFromSuperview];
        [self.secondLabel removeFromSuperview];
        [self.colonAfterMinuteLabel removeFromSuperview];
        [self.colonAfterDayLabel removeFromSuperview];
        [self.colonAfterHourLabel removeFromSuperview];
        
        
        UIView * btn = [[UIView alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
        btn.backgroundColor = [UIColor redColor];
        [self addSubview:btn];
        
    }
}

// 通过时间间隔计算具体时间(天,小时,分,秒)
- (void)getTimeFromTimeInterval : (NSInteger)timeInterval
{
    // 通过时间间隔获取天数 小时数 分钟数 秒数
    NSInteger ms = timeInterval;
    NSInteger ss = 1;
    NSInteger mi = ss * 60;
    NSInteger hh = mi * 60;
    NSInteger dd = hh * 24;
    
    // 剩余的
    NSInteger day = ms / dd;// 天
    NSInteger hour = (ms - day * dd) / hh;// 时
    NSInteger minute = (ms - day * dd - hour * hh) / mi;// 分
    NSInteger second = (ms - day * dd - hour * hh - minute * mi) / ss;// 秒
//    if (second<0) {
//        NSLog(@"过期了");
//    }
    self.dayLabel.text = [NSString stringWithFormat:@"%zd天",day];
    self.hourLabel.text = [NSString stringWithFormat:@"%zd时",hour];
    self.minuteLabel.text = [NSString stringWithFormat:@"%zd分",minute];
    self.secondLabel.text = [NSString stringWithFormat:@"%zd秒",second];
}

@end
