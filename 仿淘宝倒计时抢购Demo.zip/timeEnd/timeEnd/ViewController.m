//
//  ViewController.m
//  timeEnd
//
//  Created by bean on 16/2/18.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import "ViewController.h"
#import "CountDownView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    // 初始化后添加 显示时间倒计时
    CountDownView *countDownView = [[CountDownView alloc] initWithFrame:CGRectMake(0, 50, 100, 0)] ;
//    countDownView.timeInterval = [countDownView timeIntervalWithFormatterString:@"yyyy年-MM月-dd日 HH时-mm分-ss秒" andFutureDataString:@"2016年-2月-20日 00时-00分--00秒"] ;
    countDownView.timeInterval = [countDownView timeIntervalWithFormatterString:@"yyyyMMddHHmmss" andFutureDataString:@"20160218190645"] ;
    /**第一个参数：日期格式
       第二个参数：过期时间
     */

    [self.view addSubview:countDownView] ;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
