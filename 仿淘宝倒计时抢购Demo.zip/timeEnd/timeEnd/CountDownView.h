//
//  CountDownView.h
//  timeEnd
//
//  Created by bean on 16/2/18.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CountDownView : UIView



// 我们用七个Label来显示 (冒号也算在内)---  天数 : 小时 : 分 : 秒
@property (nonatomic,retain)UILabel *dayLabel ; // 显示天数的Label
@property (nonatomic,retain)UILabel *colonAfterDayLabel ; // 跟在小时后便的冒号
@property (nonatomic,retain)UILabel *hourLabel ; // 显示小时的Label
@property (nonatomic,retain)UILabel *colonAfterHourLabel ; // 跟在小时后便的冒号
@property (nonatomic,retain)UILabel *minuteLabel ; // 显示分钟的Label
@property (nonatomic,retain)UILabel *colonAfterMinuteLabel ; // 跟在分钟后便的label
@property (nonatomic,retain)UILabel *secondLabel ; // 显示秒数的Label

@property (nonatomic,assign)NSInteger timeInterval; // 显示秒数的Label


- (NSTimeInterval)timeIntervalWithFormatterString : (NSString *)formatterString andFutureDataString : (NSString *)futureDataString;

@end
